from django.shortcuts import render,redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.contrib import messages




# Create your views here.

def user(request):
    return render(request,'index2.html',context={})
   
def signup(request):
    if request.method == 'POST':
        # un = request.POST.get("username")
        us=request.POST.get('name')
        em = request.POST.get("email")
        pas = request.POST.get("password")
        userObj=User.objects.create_user(us,em,pas)
        userObj.save()
    else:
        return render(request, "signupform.html", context={})
    return redirect("ggc")

def index(request):
    return render(request,'index.html')

def add(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('address')
        c=request.POST.get('staffid')
        d=request.POST.get('Department')
        e=request.POST.get('ph')
        f= Employee(name=a,address=b,staffid=c,department1=d,phonenumber=e)
        f.save()
        

    else:
        return render(request,'page4.html',context={})
    return HttpResponse('Data is inserted sucessfully')
       
    
def view(request):
    emps=Employee.objects.all()
    return render(request,'ll.html',context={'emps':emps})

def delete(request, eid):
    a = Employee.objects.get(staffid=eid)
    a.delete()
    messages.success(request, "Employee Deleted successfully")
    return HttpResponse('employee deleted success')

def list(request):
    emps = Employee.objects.all()
    return render(request,'del.html',context={'emps':emps})

def sadd(request):
    if request.method == 'POST':
        a=request.POST.get('empname')
        b=request.POST.get('department')
        c=request.POST.get('staffid')
        d=request.POST.get('salary')
        e=request.POST.get('tech')
        g=request.POST.get('work')
        f= Salary(empname=a,department=b,staffid=c,salary=d,tech=e,work=g)
        f.save()
    
    else:
        return render(request,'sadd.html',context={})
    return HttpResponse('appriasaial added')

def sview(request):
    emps=Salary.objects.all()
    return render(request,'sv.html',context={'emps':emps})

def dadd(request):
    if request.method == 'POST':
        a=request.POST.get('empname')
        b=request.POST.get('staffid')
        c=request.POST.get('dep')
        d=request.POST.get('depid')
        e=request.POST.get('date')
        f=request.POST.get('in')
        g=request.POST.get('out')
        h= Department(empname=a,staffid=b,department=c,depid=d,date=e,checkin=f,checkout=g)
        h.save()
    else:
        return render(request,'dadd.html',context={})
    return HttpResponse('Data is inserted sucessfully')

def dlist(request):
    dlist = Department.objects.all()
    return render(request,'ld.html',context={'dlist':dlist})

def dfilt(request):
    filt= Department.objects.filter(checkin__startswith=2)
  
    if filt:
        return render(request,'df.html',context={'filt':filt})
        return redirect

def dfilt1(request):
    filt1= Department.objects.filter(checkin__startswith=9)
  
    if filt1:
        return render(request,'df2.html',context={'filt1':filt1})

def sfilt(request):
    filt1= Salary.objects.filter(staffid__startswith=6)
    print(filt1)
  
    if filt1:
        return render(request,'sf.html',context={'filt1':filt1})
    
  






